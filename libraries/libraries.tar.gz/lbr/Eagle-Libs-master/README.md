# Eagle Libraries

## Installation
Download the complete libraries [here](https://github.com/watterott/Eagle-Libs/archive/master.zip).

Copy the content of the ZIP-Archive to your Eagle library folder.

Further infos: https://learn.sparkfun.com/tutorials/how-to-install-and-setup-eagle/using-the-sparkfun-libraries
